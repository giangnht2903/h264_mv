import hashlib
import shutil

print("=== Embedding Secret ===")

user_token = input(
    "Enter POSITION_TOKEN: "
).strip()

with open("position_token.txt", "r") as f:
    real_token = f.read().strip()

if user_token != real_token:

    print("[-] Invalid POSITION_TOKEN")
    exit(1)

with open("secret_bits.txt", "r") as f:
    bits = f.read().strip()

with open("mv_data.txt", "r") as f:

    vectors = [int(x.strip()) for x in f]

with open("positions.txt", "r") as f:

    positions = [int(x.strip()) for x in f]

embedded = vectors[:]

for i, bit in enumerate(bits):

    pos = positions[i]

    mv = embedded[pos]

    if bit == "0":

        if abs(mv) % 2 == 1:

            embedded[pos] = mv + 1

    else:

        if abs(mv) % 2 == 0:

            embedded[pos] = mv + 1

with open("embedded_vectors.txt", "w") as f:

    for mv in embedded:
        f.write(str(mv) + "\n")

stego_token = hashlib.sha256(
    str(embedded).encode()
).hexdigest()[:8]

with open("stego_token.txt", "w") as f:
    f.write(stego_token)

shutil.copy("input.mp4", "stego.mp4")

print("[+] Stego embedding completed")
print(f"STEGO_TOKEN={stego_token}")
