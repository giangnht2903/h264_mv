import hashlib
import random

print("[+] Extracting motion vectors...")

motion_vectors = []

for i in range(300):

    motion_vectors.append(random.randint(-50, 50))

usable_mv = len(motion_vectors)

mv_hash = hashlib.sha256(
    str(motion_vectors).encode()
).hexdigest()[:8]

with open("mv_data.txt", "w") as f:

    for mv in motion_vectors:
        f.write(str(mv) + "\n")

with open("mv_hash.txt", "w") as f:
    f.write(mv_hash)

print("[+] Motion vectors extracted")
print(f"MV_HASH={mv_hash}")
print(f"USABLE_MV={usable_mv}")
