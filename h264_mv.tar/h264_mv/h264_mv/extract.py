import random

print("=== Extract Secret ===")

key = input("Enter KEY: ").strip()
mv_hash = input("Enter MV_HASH: ").strip()
secret_bits = int(input("Enter SECRET_BITS: ").strip())
stego_token = input("Enter STEGO_TOKEN: ").strip()

with open("stego_token.txt", "r") as f:

    real_token = f.read().strip()

if stego_token != real_token:

    print("[-] Invalid STEGO_TOKEN")
    exit(1)

with open("embedded_vectors.txt", "r") as f:

    vectors = [int(x.strip()) for x in f]

usable_mv = len(vectors)

random.seed(key + mv_hash)

positions = random.sample(
    range(usable_mv),
    secret_bits
)

bits = ""

for pos in positions:

    mv = vectors[pos]

    if abs(mv) % 2 == 0:
        bits += "0"
    else:
        bits += "1"

chars = []

for i in range(0, len(bits), 8):

    byte = bits[i:i+8]

    if len(byte) == 8:

        chars.append(chr(int(byte, 2)))

secret = ''.join(chars)

with open("result.txt", "w") as f:
    f.write(secret)

print("[+] Extraction complete")
print(f"[+] Extracted secret: {secret}")
