print("=== Verify Secret ===")

user_secret = input(
    "Enter extracted secret: "
).strip()

with open("secret.txt", "r") as f:
    real_secret = f.read().strip()

if user_secret == real_secret:

    print("[+] Verification successful")

else:

    print("[-] Verification failed")
