import hashlib

with open("secret.txt", "r") as f:
    secret = f.read().strip()

bits = ''.join(format(ord(c), '08b') for c in secret)

secret_hash = hashlib.sha256(
    bits.encode()
).hexdigest()[:8]

with open("secret_bits.txt", "w") as f:
    f.write(bits)

print("[+] Secret prepared")
print(f"SECRET_BITS={len(bits)}")
print(f"SECRET_HASH={secret_hash}")
