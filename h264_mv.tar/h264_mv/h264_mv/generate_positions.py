import hashlib
import random

print("=== Generate Random Positions ===")

key = input("Enter KEY: ").strip()
mv_hash = input("Enter MV_HASH: ").strip()
secret_bits = int(input("Enter SECRET_BITS: ").strip())
usable_mv = int(input("Enter USABLE_MV: ").strip())

seed = key + mv_hash

random.seed(seed)

positions = random.sample(
    range(usable_mv),
    secret_bits
)

position_token = hashlib.sha256(
    str(positions).encode()
).hexdigest()[:8]

with open("positions.txt", "w") as f:

    for pos in positions:
        f.write(str(pos) + "\n")

with open("position_token.txt", "w") as f:
    f.write(position_token)

print("[+] Random positions generated")
print(f"POSITION_TOKEN={position_token}")
